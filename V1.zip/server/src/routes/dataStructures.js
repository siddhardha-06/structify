import express from 'express';
import { DataStructure } from '../models/DataStructure.js';

export const router = express.Router();

// GET /api/ds - list minimal info
router.get('/', async (_req, res, next) => {
  try {
    const list = await DataStructure.find({}, { _id: 0, slug: 1, name: 1, tags: 1, order: 1 })
      .sort({ order: 1, name: 1 })
      .lean();
    res.json(list);
  } catch (e) {
    next(e);
  }
});

// GET /api/ds/:slug - full details including snippets
router.get('/:slug', async (req, res, next) => {
  try {
    const ds = await DataStructure.findOne({ slug: req.params.slug }).lean();
    if (!ds) return res.status(404).json({ error: 'Not found' });
    res.json(ds);
  } catch (e) {
    next(e);
  }
});

// GET /api/ds/:slug/snippets?lang=c
router.get('/:slug/snippets', async (req, res, next) => {
  try {
    const { slug } = req.params;
    const { lang } = req.query;
    const ds = await DataStructure.findOne({ slug }, { codeSnippets: 1, _id: 0 }).lean();
    if (!ds) return res.status(404).json({ error: 'Not found' });
    let snippets = ds.codeSnippets || [];
    if (lang) snippets = snippets.filter(s => s.language?.toLowerCase() === String(lang).toLowerCase());
    res.json(snippets);
  } catch (e) {
    next(e);
  }
});
