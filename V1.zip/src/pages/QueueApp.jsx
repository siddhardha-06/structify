import React, { useMemo, useRef, useState } from 'react'
import TextType from '../TextType'
import CodeModal from '../components/CodeModal'

function QBox({ value, index, role, highlight }) {
  return (
    <div className={`relative rounded-xl border px-6 py-4 min-w-[72px] text-center select-none transition-all duration-300 ${
      highlight ? 'border-emerald-500/80 bg-emerald-500/10 scale-[1.03] shadow-[0_0_0_2px_rgba(16,185,129,0.25)]' : 'border-white/10 bg-white/5 hover:border-white/20'
    }`}>
      <div className="text-xs text-slate-400 absolute -top-3 left-1/2 -translate-x-1/2 bg-black px-2 rounded-full border border-white/10">{index}</div>
      <div className="text-lg font-semibold">{value}</div>
      <div className="mt-1 text-[10px] uppercase tracking-wider text-slate-400">{role}</div>
    </div>
  )
}

export default function QueueApp() {
  const [queue, setQueue] = useState([])
  const [highlightIndex, setHighlightIndex] = useState(null)
  const [message, setMessage] = useState('')
  const [showCode, setShowCode] = useState(false)

  const valRef = useRef(null)
  const sizeRef = useRef(null)

  const size = queue.length

  const visualize = useMemo(() => {
    if (queue.length === 0) return <div className="text-slate-400">Queue is empty</div>
    return (
      <div className="flex items-center flex-wrap gap-3">
        {queue.map((v, i) => (
          <QBox
            key={i}
            value={v}
            index={i}
            role={i === 0 ? 'front' : i === queue.length - 1 ? 'rear' : 'in-queue'}
            highlight={i === highlightIndex}
          />
        ))}
      </div>
    )
  }, [queue, highlightIndex])

  function flash(i, note) {
    setHighlightIndex(i)
    if (note) setMessage(note)
    setTimeout(() => setHighlightIndex(null), 600)
  }

  function createQueue() {
    const n = parseInt(sizeRef.current?.value || '6', 10)
    const next = Array.from({ length: Math.max(0, Math.min(16, n)) }, () => Math.floor(Math.random() * 90) + 10)
    setQueue(next)
    setMessage(`Created queue with ${next.length} items`)
    if (next.length) flash(0)
  }

  function enqueue() {
    const value = valRef.current?.value?.trim()
    if (!value) return setMessage('Enter a value to enqueue')
    const next = [...queue, value]
    setQueue(next)
    setMessage(`Enqueued ${value}`)
    flash(next.length - 1)
  }

  function dequeue() {
    if (!queue.length) return setMessage('Queue is empty')
    const [removed, ...rest] = queue
    setQueue(rest)
    setMessage(`Dequeued ${removed}`)
    if (rest.length) flash(0)
  }

  function peekFront() {
    if (!queue.length) return setMessage('Queue is empty')
    setMessage(`Front: ${queue[0]}`)
    flash(0)
  }

  function peekRear() {
    if (!queue.length) return setMessage('Queue is empty')
    setMessage(`Rear: ${queue[queue.length - 1]}`)
    flash(queue.length - 1)
  }

  function reset() {
    setQueue([])
    setMessage('Cleared queue')
    setHighlightIndex(null)
  }

  return (
    <div className="min-h-screen flex flex-col">
      <header className="border-b border-white/10 bg-white/5/20 backdrop-blur px-4 sm:px-8 py-4">
        <div className="max-w-6xl mx-auto flex flex-col items-start gap-1">
          <h1 className="text-xl sm:text-2xl font-semibold">Queue Visualizer</h1>
          <TextType
            text={["FIFO structure", "Enqueue • Dequeue • Peek"]}
            typingSpeed={75}
            pauseDuration={1400}
            showCursor={true}
            className="text-sm text-slate-300"
            cursorCharacter="|"
          />
        </div>
      </header>

      <main className="flex-1 px-4 sm:px-8 py-6">
        <div className="max-w-6xl mx-auto grid gap-6 lg:grid-cols-[1fr_360px]">
          {/* Visualization */}
          <section className="rounded-2xl border border-white/10 bg-white/5 p-5 sm:p-6">
            <div className="mb-4 flex items-center justify-between">
              <div className="text-slate-400 text-sm">Size: <span className="text-white font-medium">{size}</span></div>
              <div className="text-slate-400 text-sm h-5">{message}</div>
            </div>
            <div className="overflow-x-auto pb-2">
              {visualize}
            </div>
            <div className="mt-6">
              <button onClick={()=>setShowCode(true)} className="px-4 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-sm font-medium">View C Code</button>
            </div>
          </section>

          {/* Controls */}
          <aside className="rounded-2xl border border-white/10 bg-white/5 p-5 sm:p-6 space-y-4">
            <div className="grid grid-cols-2 gap-3">
              <div className="col-span-2">
                <label className="text-xs text-slate-400">Create with N items</label>
                <div className="mt-1 flex gap-2">
                  <input ref={sizeRef} type="number" min="0" max="16" defaultValue={6} className="w-24 bg-black/60 border border-white/10 rounded-lg px-3 py-2 text-sm outline-none focus:border-emerald-500/60"/>
                  <button onClick={createQueue} className="px-3 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-sm">Create</button>
                </div>
              </div>

              <div className="col-span-2">
                <label className="text-xs text-slate-400">Value</label>
                <input ref={valRef} placeholder="e.g. 42" className="mt-1 w-full bg-black/60 border border-white/10 rounded-lg px-3 py-2 text-sm outline-none focus:border-emerald-500/60" />
              </div>

              <button onClick={enqueue} className="col-span-2 px-3 py-2 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-sm">Enqueue</button>
              <button onClick={dequeue} className="col-span-2 px-3 py-2 rounded-lg bg-rose-600 hover:bg-rose-500 text-sm">Dequeue</button>

              <div className="grid grid-cols-2 gap-3 col-span-2">
                <button onClick={peekFront} className="px-3 py-2 rounded-lg bg-sky-600 hover:bg-sky-500 text-sm">Peek Front</button>
                <button onClick={peekRear} className="px-3 py-2 rounded-lg bg-amber-600 hover:bg-amber-500 text-sm">Peek Rear</button>
              </div>

              <button onClick={reset} className="col-span-2 px-3 py-2 rounded-lg bg-white/10 hover:bg-white/20 text-sm">Reset</button>
            </div>
          </aside>
        </div>
      </main>

      <footer className="px-4 sm:px-8 py-6">
        <div className="max-w-6xl mx-auto text-center">
          <div className="text-xs text-slate-500">Queue · FIFO</div>
          <div className="mt-3">
            <a href="/menu.html" className="text-sm text-emerald-400 hover:underline">Back to Menu</a>
          </div>
        </div>
      </footer>
      <CodeModal slug="queue" open={showCode} onClose={()=>setShowCode(false)} />
    </div>
  )
}
