import React, { useState, useRef } from 'react'

export default function StackApp(){
  const [stack, setStack] = useState([])
  const [value, setValue] = useState('')
  const [capacity, setCapacity] = useState(10)
  const [log, setLog] = useState('')
  const inputRef = useRef(null)

  function push(){
    if(stack.length >= capacity){ setLog('Stack overflow — capacity reached'); return }
    if(value === ''){ setLog('Enter a value to push'); return }
    setStack(prev => [...prev, value])
    setLog(`Pushed: ${value}`)
    setValue('')
    inputRef.current?.focus()
  }
  function pop(){
    if(!stack.length){ setLog('Stack underflow — nothing to pop'); return }
    const popped = stack[stack.length -1]
    setStack(prev => prev.slice(0,-1))
    setLog(`Popped: ${popped}`)
  }
  function peek(){
    if(!stack.length){ setLog('Stack is empty'); return }
    setLog(`Top: ${stack[stack.length -1]}`)
  }
  function printAll(){
    setLog(stack.length ? `Stack (top->bottom): ${stack.slice().reverse().join(', ')}` : 'Stack is empty')
  }
  function clear(){ setStack([]); setLog('Cleared stack') }

  return (
    <div className="min-h-screen flex items-center justify-center theme-gradient">
      <div className="bg-white w-[520px] max-w-[94vw] p-6 rounded-xl shadow-xl text-[#111827]">
        <h1 className="text-xl font-semibold mb-3">Stack Visualizer</h1>
        <div className="flex gap-2 mb-3">
          <input ref={inputRef} value={value} onChange={e=>setValue(e.target.value)} placeholder="Value to push" className="flex-1 px-3 py-2 rounded-md border border-gray-300" />
          <button onClick={push} className="px-4 py-2 rounded-md bg-indigo-600 text-white">Push</button>
          <button onClick={pop} className="px-4 py-2 rounded-md bg-emerald-600 text-white">Pop</button>
        </div>
        <div className="flex items-center gap-2 mb-3 text-sm text-gray-600">
          <label>Capacity</label>
          <input type="number" min={1} max={100} value={capacity} onChange={e=>setCapacity(Math.max(1, Number(e.target.value||10)))} className="w-20 px-2 py-1 rounded-md border border-gray-300" />
          <div className="ml-auto flex gap-2">
            <button onClick={peek} className="px-2 py-1 rounded-md border border-gray-300 bg-white">Peek</button>
            <button onClick={printAll} className="px-2 py-1 rounded-md border border-gray-300 bg-white">Print</button>
            <button onClick={clear} className="px-2 py-1 rounded-md border border-gray-300 bg-white">Clear</button>
          </div>
        </div>
        <div className="border border-dashed border-gray-300 rounded-lg min-h-[220px] max-h-[300px] overflow-auto flex flex-col-reverse gap-2 p-3 bg-gradient-to-b from-slate-50 to-white">
          {stack.length === 0 ? <div className="text-center text-gray-400 py-8">Stack is empty</div> : stack.map((item,i)=>{
            const isTop = i === stack.length -1
            const hue = Math.round((i*40)%360)
            return (
              <div key={i} className={`relative px-4 py-3 rounded-md text-white font-semibold`} style={{background:`hsl(${hue} 70% 45%)`}}>
                <div className="text-center">{item}</div>
                {isTop && <small className="absolute right-2 top-1/2 -translate-y-1/2 text-xs">TOP</small>}
              </div>
            )
          })}
        </div>
        <div className="mt-4 text-sm text-gray-600">
          <div>Size: {stack.length} / {capacity}</div>
          <div className="mt-2 text-gray-700">Log: {log || '-'} </div>
        </div>
        <div className="mt-6 text-center text-xs text-gray-500"><a href="/menu.html" className="text-emerald-600 hover:underline">Back to Menu</a></div>
      </div>
    </div>
  )
}
