//array
const array=document.getElementById("arr");
array.addEventListener("click",()=>{
    window.location.href="array.html";
})

//linked list
const ll=document.getElementById("ll");
ll.addEventListener("click",()=>{
    window.location.href="linked_list.html";
})

//stack
const st=document.getElementById("st");
st.addEventListener("click",()=>{
    window.location.href="stack.html";
})

//queue
const que=document.getElementById("que");
que.addEventListener("click",()=>{
    window.location.href="queue.html";
})

//binary tree
const bint=document.getElementById("bint");
st.addEventListener("click",()=>{
    window.location.href="binary_tree.html";
})

const bst=document.getElementById("bst");
bst.addEventListener("click",()=>{
    window.location.href="bst.html";
})

