import ReactDOM from 'react-dom/client'
import './index.css'
import ArrayApp from './pages/ArrayApp.jsx'

ReactDOM.createRoot(document.getElementById('root')).render(
  <ArrayApp />
)
