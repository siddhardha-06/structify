import './index.css'
import llVideo from './LL_video.mp4'
import TextType from './TextType'
import Aurora from './components/Aurora'

function App() {
	const navigate = (path) => {
		window.location.href = path
	}

	return (
		<div className="app-root relative min-h-screen">
			{/* Aurora background layer for second page (menu) */}
			<div className="app-aurora-wrapper">
				<Aurora colorStops={["#5227FF", "#7cff67", "#5227FF"]} amplitude={1.0} blend={0.55} />
			</div>
			<div className="app-content relative z-10">
				<header>
					<div className="text-3xl font-bold font-mono mb-4 mt-4">
						<TextType
							text={["Welcome to Visualgo", "Visualising DSA", "Happy coding!"]}
							typingSpeed={75}
							pauseDuration={1500}
							showCursor={true}
							cursorCharacter="|"
						/>
					</div>
				</header>

				<article>
					<div className="flex flex-wrap justify-around gap-6 mb-10 mt-10">
						{/* Array */}
						<button
							type="button"
							className="containers flex justify-center items-center text-xl py-6 px-6 w-[200px] text-white bg-gradient-to-r from-red-400 via-red-500 to-red-600 hover:bg-gradient-to-br focus:ring-4 focus:outline-none focus:ring-red-300 dark:focus:ring-red-800 font-medium rounded-lg"
							onClick={() => navigate('array.html')}
						>
							<h3>Array</h3>
						</button>

						{/* Linked List tile with video */}
						<button
							type="button"
							className="containers relative overflow-hidden flex justify-center items-center text-xl py-6 px-6 w-[300px] h-[200px] text-white bg-transparent hover:bg-transparent focus:ring-4 focus:outline-none focus:ring-green-300 dark:focus:ring-green-800 font-medium rounded-lg"
							onClick={() => navigate('linked_list.html')}
						>
							<div className="relative z-10 flex items-end justify-center w-full h-full pointer-events-none">
								<h3 className="text-white">Linked List</h3>
							</div>
							<video
								className="absolute inset-0 z-0 w-full h-full object-cover opacity-90"
								autoPlay
								loop
								muted
								playsInline
								src={llVideo}
								aria-hidden="true"
							/>
						</button>

						{/* Stack */}
						<button
							type="button"
							className="containers flex justify-center items-center text-xl py-6 px-6 w-[200px] bg-gradient-to-r from-cyan-400 via-cyan-500 to-cyan-600 hover:bg-gradient-to-br focus:ring-4 focus:outline-none focus:ring-cyan-300 dark:focus:ring-cyan-800 font-medium rounded-lg text-white"
							onClick={() => navigate('stack.html')}
						>
							<h3>Stack</h3>
						</button>
					</div>

					<div className="flex flex-wrap justify-around gap-6">
						<button
							type="button"
							className="containers flex justify-center items-center text-xl py-6 px-6 w-[200px] text-gray-900 bg-white border border-gray-300 focus:outline-none hover:bg-gray-100 focus:ring-4 focus:ring-gray-100 font-medium rounded-lg dark:bg-gray-800 dark:text-white dark:border-gray-600 dark:hover:bg-gray-700 dark:hover:border-gray-600"
							onClick={() => navigate('queue.html')}
						>
							<h3>Queue</h3>
						</button>
						<button
							type="button"
							className="containers flex justify-center items-center text-xl py-6 px-6 w-[200px] text-gray-900 bg-gradient-to-r from-lime-200 via-lime-400 to-lime-500 hover:bg-gradient-to-br focus:ring-4 focus:outline-none focus:ring-lime-300 dark:focus:ring-lime-800 font-medium rounded-lg"
							onClick={() => navigate('binarytree.html')}
						>
							<h3>Binary Tree</h3>
						</button>
						<button
							type="button"
							className="containers flex justify-center items-center text-xl py-6 px-6 w-[200px] text-white bg-gradient-to-r from-teal-400 via-teal-500 to-teal-600 hover:bg-gradient-to-br focus:ring-4 focus:outline-none focus:ring-teal-300 dark:focus:ring-teal-800 font-medium rounded-lg"
							onClick={() => navigate('bst.html')}
						>
							<h3>Binary Search Tree</h3>
						</button>
					</div>
					<aside className="text-center h-16 flex items-center justify-center bg-transparent border-t border-white/10 mt-10">
						<a href="#" className="text-sm text-slate-300 hover:text-white">About us</a>
					</aside>
				</article>
			</div>
			<footer className="py-6 text-center text-xs text-gray-300">© 2025 VisuAlgo Replica</footer>
		</div>
	);
}

export default App
